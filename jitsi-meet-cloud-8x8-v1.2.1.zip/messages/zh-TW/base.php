<?php

return [
    'Close' => '關閉',
    'Join' => '加入',
    'Name' => '名稱',
    '<strong>Jitsi</strong> module configuration' => '',
    'Application ID shared with a private Jitsi server used to generate JWT token for authentication. Default: empty, no JWT token authentication will be used.' => '',
    'Application secret shared with a private Jitsi server used to sign JWT token for authentication. Default: empty, needed if JWT token should be generated.' => '',
    'Can access Jitsi Meet' => '',
    'Can access Jitsi Meet from main navigation.' => '',
    'Default is meet.jit.si without "https://" prefix.' => '',
    'Default: Jitsi Meet' => '',
    'Default: empty, useful for public Jitsi server' => '',
    'Enable JWT Authentication' => '',
    'Open conference room' => '',
    'Open in new window?' => '',
];
